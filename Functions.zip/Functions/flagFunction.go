package function

func AfterFlag(afterFlag string) {
	ress := ""
	ressPonc := ""
	for _, char := range afterFlag {
		if ress == "" && IsPonc(char) {
			ressPonc += string(char)
		} else if !IsPonc(char) {
			y := len(result) - 1
			for y >= 0 {
				if result[y] != "" {
					result[y] += ressPonc
					ressPonc = ""
					break
				}
				y--
			}
			ress += string(char)
		} else {
			result = append(result, ress)
			ressPonc += string(char)
			ress = ""
		}
	}
	if ress != "" {
		result = append(result, ress)
	}
	y := len(result) - 1
	for y >= 0 {
		if result[y] != "" {
			result[y] += ressPonc
			break
		}
		y--
	}
	ress = ""
	ressPonc = ""
	result = append(result, ress)
}
