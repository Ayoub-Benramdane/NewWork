package function

func SplitFlqgs(str, newStr string, result []string, i int) ([]string, int, string) {
	// s,err := strconv.Atoi("k")
	// if err != nil {
	// 	fmt.Println(err)
	// 	return result, i, newStr
	// }
	flags := []string{"(hex)", "(bin)", "(cap)", "(up)", "(low)", "(cap, ", "(up, ", "(low, "}
	stf := ""
	// ch := 0
	for j := i; j < len(str); j++ {
		stf += string(str[j])
		if str[j] == ')' {
			// ch = 1
			break
		}
		if str[j] == ' ' {
			// ch = 2
			break
		}

	}
	
	for _, c := range flags {
		if stf == c {
			if newStr != "" {

				
			}
			return append(result, stf), i + len(stf) - 1, newStr
		}
	}
	return result, i, newStr
}
