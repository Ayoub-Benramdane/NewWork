package function

func SingleQuots(result []string, str string, i int) ([]string, int) {
	strQuots := ""
	for j := i; j < len(str); j++ {
		if i > 0 {
			if str[i-1] != ' ' && str[i-1] != '\n'  {
				break
			}
		}
		if i < len(str) - 1 {
			if str[i+1] != ' ' && str[i+1] != '\n' {
				break
			}
		}
		if str[i] != '\'' {
			strQuots += string(str[i])
		}
		if str[i] == '\'' && j != i {
			//result = SplitSingleQuots(result, strQuots)
			i += len(strQuots) - 1
		}
	}
	return result, i
}

func SplitWhiteSpaces(str string) []string {
	result := []string{}
	spaceStr := ""
	newStr := ""
	count := 0
	for i := 0; i < len(str); i++ {
		if count == 0 {
			if IsPonc(rune(str[i])) {
				count++
				spaceStr = ""
			}
		}
		if str[i] == '\'' {
			result, i = SingleQuots(result, str, i)
		}
		if str[i] == '(' {
			result, i, newStr = SplitFlqgs(str, newStr, result, i)
			continue
		}
		if str[i] != ' ' && str[i] != '\n' {
			result, spaceStr, count, newStr = SpaceStr(result, newStr, spaceStr, str[i:], count)
		}
		if str[i] == '\n' {
			newStr += string(str[i])
			result = append(result, newStr)
			newStr = ""
		}
		if str[i] == ' ' {
			result, newStr, spaceStr = NewStr(result, spaceStr, newStr, str[i:], count)
		}
	}
	if newStr != "" {
		result = append(result, newStr)
	}
	return result
}
