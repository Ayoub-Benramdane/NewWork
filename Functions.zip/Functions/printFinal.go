package function

func PrintStrFinal(slice []string) string {
	res := ""
	count := 0
	for i := 0; i < len(slice); i++ {
		if slice[i][len(slice[i])-1] == '\n' {
			res += slice[i]
		} else if slice[i] == "'" && count == 0 {
			count++
			res += slice[i]
		} else if slice[i] == "'" {
			count = 0
			res += slice[i] + " "
		} else if i < len(slice)-1 {
			if slice[i+1] == "'" && count != 0 {
				res += slice[i]
			} else {
				res += slice[i] + " "
			}
		} else {
			res += slice[i]
		}
	}
	return res
}
