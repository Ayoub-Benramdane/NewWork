package function

import (
	"fmt"
	"strconv"
)
var result []string

func PrintStr(args []string) string {
	sliceFinal := []string{}
	flags := []string{"(hex)", "(bin)", "(cap)", "(up)", "(low)"}
	flagsParam := []string{"(hex,", "(bin,", "(cap,", "(up,", "(low,"}
	index := 0
	res := ""
	for i := 0; i < len(args); i++ {
		isFlag := false
		x := len(result) - 1
		if x < 0 {
			for _, flag := range flags {
				if len(args[i]) >= 5 && (args[i][0:5] == flag || args[i][0:4] == "(up)") {
					count := 0
					afterFlag := ""
					for _, c := range args[i] {
						if c == ')' {
							count++
						} else if count != 0 {
							afterFlag += string(c)
						}
					}
					if afterFlag != "" {
						ress := ""
						ressPonc := ""
						for _, char := range afterFlag {
							if ress == "" && IsPonc(char) {
								ressPonc += string(char)
							} else if !IsPonc(char) {
								y := len(result) - 1
								for y >= 0 {
									if result[y] != "" {
										result[y] += ressPonc
										ressPonc = ""
										break
									}
									y--
								}
								ress += string(char)
							} else {
								result = append(result, ress)
								ressPonc += string(char)
								ress = ""
							}
						}
						if ress != "" {
							result = append(result, ress)
						}
						y := len(result) - 1
						for y >= 0 {
							if result[y] != "" {
								result[y] += ressPonc
								break
							}
							y--
						}
						ress = ""
						ressPonc = ""
						result = append(result, ress)
					}
					isFlag = true
					break
				}
			}
			for _, flag := range flagsParam {
				if args[i] == flag {
					if IsNum(rune(args[i+1][0])) {
						count := 0
						afterFlag := ""
						for _, c := range args[i+1] {
							if c == ')' {
								count++
							} else if count != 0 {
								afterFlag += string(c)
							}
						}
						if afterFlag != "" {
							ress := ""
							ressPonc := ""
							for _, char := range afterFlag {
								if ress == "" && IsPonc(char) {
									ressPonc += string(char)
								} else if !IsPonc(char) {
									y := len(result) - 1
									for y >= 0 {
										if result[y] != "" {
											result[y] += ressPonc
											ressPonc = ""
											break
										}
										y--
									}
									ress += string(char)
								} else {
									result = append(result, ress)
									ressPonc += string(char)
									ress = ""
								}
							}
							if ress != "" {
								result = append(result, ress)
							}
							y := len(result) - 1
							for y >= 0 {
								if result[y] != "" {
									result[y] += ressPonc
									break
								}
								y--
							}
							ress = ""
							ressPonc = ""
							result = append(result, ress)
						}
						isFlag = true
						i += 1
						break
					} else {
						result = append(result, args[i])
						isFlag = true
						break
					}
				}
			}
		}
		if isFlag {
			continue
		}
		if len(args[i]) >= 5 && (args[i][0:5] == "(hex)" || args[i][0:5] == "(bin)") {
			result[x] = strconv.Itoa(int(ConvDic(result[x], args[i][0:5])))
			count := 0
			afterFlag := ""
			for _, c := range args[i] {
				if c == ')' {
					count++
				} else if count != 0 {
					afterFlag += string(c)
				}
			}
			if afterFlag != "" {
				ress := ""
				ressPonc := ""
				for _, char := range afterFlag {
					if ress == "" && IsPonc(char) {
						ressPonc += string(char)
					} else if !IsPonc(char) {
						y := len(result) - 1
						for y >= 0 {
							if result[y] != "" {
								result[y] += ressPonc
								ressPonc = ""
								break
							}
							y--
						}
						ress += string(char)
					} else {
						result = append(result, ress)
						ressPonc += string(char)
						ress = ""
					}
				}
				if ress != "" {
					result = append(result, ress)
				}
				y := len(result) - 1
				for y >= 0 {
					if result[y] != "" {
						result[y] += ressPonc
						break
					}
					y--
				}
				ress = ""
				ressPonc = ""
				result = append(result, ress)
			}
			continue
		} else if args[i] == "(up)" {
			result[x] = Up(result[x])
			count := 0
			afterFlag := ""
			for _, c := range args[i] {
				if c == ')' {
					count++
				} else if count != 0 {
					afterFlag += string(c)
				}
			}
			if afterFlag != "" {
				ress := ""
				ressPonc := ""
				for _, char := range afterFlag {
					if ress == "" && IsPonc(char) {
						ressPonc += string(char)
					} else if !IsPonc(char) {
						y := len(result) - 1
						for y >= 0 {
							if result[y] != "" {
								result[y] += ressPonc
								ressPonc = ""
								break
							}
							y--
						}
						ress += string(char)
					} else {
						result = append(result, ress)
						ressPonc += string(char)
						ress = ""
					}
				}
				if ress != "" {
					result = append(result, ress)
				}
				y := len(result) - 1
				for y >= 0 {
					if result[y] != "" {
						result[y] += ressPonc
						break
					}
					y--
				}
				ress = ""
				ressPonc = ""
				result = append(result, ress)
			}
		} else if args[i] == "(low)" {
			result[x] = Low(result[x])
			count := 0
			afterFlag := ""
			for _, c := range args[i] {
				if c == ')' {
					count++
				} else if count != 0 {
					afterFlag += string(c)
				}
			}
			if afterFlag != "" {
				ress := ""
				ressPonc := ""
				for _, char := range afterFlag {
					if ress == "" && IsPonc(char) {
						ressPonc += string(char)
					} else if !IsPonc(char) {
						y := len(result) - 1
						for y >= 0 {
							if result[y] != "" {
								result[y] += ressPonc
								ressPonc = ""
								break
							}
							y--
						}
						ress += string(char)
					} else {
						result = append(result, ress)
						ressPonc += string(char)
						ress = ""
					}
				}
				if ress != "" {
					result = append(result, ress)
				}
				y := len(result) - 1
				for y >= 0 {
					if result[y] != "" {
						result[y] += ressPonc
						break
					}
					y--
				}
				ress = ""
				ressPonc = ""
				result = append(result, ress)
			}
		} else if args[i] == "(cap)" {
			result[x] = Cap(result[x])
			count := 0
			afterFlag := ""
			for _, c := range args[i] {
				if c == ')' {
					count++
				} else if count != 0 {
					afterFlag += string(c)
				}
			}
			if afterFlag != "" {
				ress := ""
				ressPonc := ""
				for _, char := range afterFlag {
					if ress == "" && IsPonc(char) {
						ressPonc += string(char)
					} else if !IsPonc(char) {
						y := len(result) - 1
						for y >= 0 {
							if result[y] != "" {
								result[y] += ressPonc
								ressPonc = ""
								break
							}
							y--
						}
						ress += string(char)
					} else {
						result = append(result, ress)
						ressPonc += string(char)
						ress = ""
					}
				}
				if ress != "" {
					result = append(result, ress)
				}
				y := len(result) - 1
				for y >= 0 {
					if result[y] != "" {
						result[y] += ressPonc
						break
					}
					y--
				}
				ress = ""
				ressPonc = ""
				result = append(result, ress)
			}
		} else if args[i] == "(up," {
			fmt.Sscanf(args[i+1], "%d)", &index)
			if index == 0 {
				result = append(result, args[i])
				continue
			} else {
				count := 0
				afterFlag := ""
				for _, c := range args[i+1] {
					if c == ')' {
						count++
					} else if count != 0 {
						afterFlag += string(c)
					}
				}
				if afterFlag != "" {
					ress := ""
					ressPonc := ""
					for _, char := range afterFlag {
						if ress == "" && IsPonc(char) {
							ressPonc += string(char)
						} else if !IsPonc(char) {
							y := len(result) - 1
							for y >= 0 {
								if result[y] != "" {
									result[y] += ressPonc
									ressPonc = ""
									break
								}
								y--
							}
							ress += string(char)
						} else {
							result = append(result, ress)
							ressPonc += string(char)
							ress = ""
						}
					}
					if ress != "" {
						result = append(result, ress)
					}
					y := len(result) - 1
					for y >= 0 {
						if result[y] != "" {
							result[y] += ressPonc
							break
						}
						y--
					}
					ress = ""
					ressPonc = ""
					result = append(result, ress)
				}
			}
			if x+1 < index {
				index = x + 1
			}
			j := x
			for {
				if result[j] != "'" {
					result[j] = Up(result[j])
				} else if result[j] == "'" {
					index++
				}
				if j <= x-index+1 {
					break
				}
				j -= 1
			}
			i += 1
		} else if args[i] == "(low," {
			fmt.Sscanf(args[i+1], "%d)", &index)
			if index == 0 {
				result = append(result, args[i])
				continue
			} else {
				count := 0
				afterFlag := ""
				for _, c := range args[i+1] {
					if c == ')' {
						count++
					} else if count != 0 {
						afterFlag += string(c)
					}
				}
				if afterFlag != "" {
					ress := ""
					ressPonc := ""
					for _, char := range afterFlag {
						if ress == "" && IsPonc(char) {
							ressPonc += string(char)
						} else if !IsPonc(char) {
							y := len(result) - 1
							for y >= 0 {
								if result[y] != "" {
									result[y] += ressPonc
									ressPonc = ""
									break
								}
								y--
							}
							ress += string(char)
						} else {
							result = append(result, ress)
							ressPonc += string(char)
							ress = ""
						}
					}
					if ress != "" {
						result = append(result, ress)
					}
					y := len(result) - 1
					for y >= 0 {
						if result[y] != "" {
							result[y] += ressPonc
							break
						}
						y--
					}
					ress = ""
					ressPonc = ""
					result = append(result, ress)
				}
			}
			if x+1 < index {
				index = x + 1
			}
			j := x
			for {
				if result[j] != "'" {
					result[j] = Low(result[j])
				} else if result[j] == "'" {
					index++
				}
				if j <= x-index+1 {
					break
				}
				j -= 1
			}
			i += 1
		} else if args[i] == "(cap," {
			fmt.Sscanf(args[i+1], "%d)", &index)
			if index == 0 {
				result = append(result, args[i])
				continue
			} else {
				count := 0
				afterFlag := ""
				for _, c := range args[i+1] {
					if c == ')' {
						count++
					} else if count != 0 {
						afterFlag += string(c)
					}
				}
				if afterFlag != "" {
					ress := ""
					ressPonc := ""
					for _, char := range afterFlag {
						if ress == "" && IsPonc(char) {
							ressPonc += string(char)
						} else if !IsPonc(char) {
							y := len(result) - 1
							for y >= 0 {
								if result[y] != "" {
									result[y] += ressPonc
									ressPonc = ""
									break
								}
								y--
							}
							ress += string(char)
						} else {
							result = append(result, ress)
							ressPonc += string(char)
							ress = ""
						}
					}
					if ress != "" {
						result = append(result, ress)
					}
					y := len(result) - 1
					for y >= 0 {
						if result[y] != "" {
							result[y] += ressPonc
							break
						}
						y--
					}
					ress = ""
					ressPonc = ""
					result = append(result, ress)
				}
			}
			if x+1 < index {
				index = x + 1
			}
			j := x
			for {
				if result[j] != "'" {
					result[j] = Cap(result[j])
				} else if result[j] == "'" {
					index++
				}
				if j <= x-index+1 {
					break
				}
				j -= 1
			}
			i += 1
		} else if args[i] == "a" || args[i] == "A" {
			l := i
			isDone := false
			for i := l; i < len(args)-1; i++ {
				if args[i] != "" && args[i] != " " {
					for j, c := range args[i+1] {
						if j == 0 && IsVowel(c) {
							result = append(result, "an")
							isDone = true
							break
						} else {
							result = append(result, "a")
							isDone = true
							break
						}
					}
				}
				if isDone {
					break
				}
			}
		} else if args[i] == "an" || args[i] == "An" {
			l := i
			isDone := false
			for i := l; i < len(args)-1; i++ {
				if args[i] != "" && args[i] != " " {
					for j, c := range args[i+1] {
						if j == 0 && !IsVowel(c) {
							result = append(result, "a")
							isDone = true
							break
						} else {
							result = append(result, "an")
							isDone = true
							break
						}
					}
				}
				if isDone {
					break
				}
			}
		} else {
			apost := ""
			resPonc := ""
			resInit := ""
			for j, char := range args[i] {
				if j == 0 && char == '\'' {
					result = append(result, string(char))
					continue
				} else if j == len(args[i])-1 && char == '\'' {
					apost = "'"
					continue
				}
				if IsVowel(char) && j == 0 {
					if x > 1 && (result[x] == "a" || result[x] == "A") {
						result[x] = "an"
					}
				}
				if resInit == "" && IsPonc(char) {
					resPonc += string(char)
				} else if !IsPonc(char) {
					y := len(result) - 1
					for y >= 0 {
						if result[y] != "" {
							result[y] += resPonc
							resPonc = ""
							break
						}
						y--
					}
					resInit += string(char)
				} else {
					result = append(result, resInit+apost)
					resPonc += string(char)
					resInit = ""
					apost = ""
				}
			}
			if resInit != "" {
				result = append(result, resInit+apost)
			}
			y := len(result) - 1
			for y >= 0 {
				if result[y] != "" {
					result[y] += resPonc
					break
				}
				y--
			}
			apost = ""
			resInit = ""
			resPonc = ""
		}

	}
	for i := 0; i < len(result); i++ {
		if result[i] != "" {
			sliceFinal = append(sliceFinal, result[i])
		}
	}
	res = PrintStrFinal(sliceFinal)
	return res
}
